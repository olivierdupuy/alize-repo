/* Écran d'ouverture de session d'Alizé OS : même fond que l'écran de démarrage, logo centré */
import QtQuick

Rectangle {
    id: root
    color: "#0b0d13"

    property int stage

    Image {
        id: logo
        anchors.centerIn: parent
        source: "/usr/share/icons/hicolor/scalable/apps/alize.svg"
        sourceSize.width: 128
        sourceSize.height: 128
        opacity: 0
    }

    // Fondu d'apparition court ; ignoré si les animations sont désactivées dans le système
    OpacityAnimator {
        target: logo
        from: 0
        to: 1
        duration: 200
        running: true
    }
}
