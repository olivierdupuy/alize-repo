// Disposition par défaut du bureau Alizé OS (API de script Plasma 6).
// Appliquée à la première connexion de chaque utilisateur :
// barre de menus en haut, dock flottant centré en bas.

// --- Fond d'écran ---
var allDesktops = desktops();
for (var i = 0; i < allDesktops.length; i++) {
    var d = allDesktops[i];
    d.wallpaperPlugin = "org.kde.image";
    d.currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];
    d.writeConfig("Image", "file:///usr/share/wallpapers/Alize/");
}

// --- Barre de menus : menu système, menu de l'application active, état, horloge ---
var bar = new Panel;
bar.location = "top";
bar.height = Math.round(gridUnit * 1.6 / 2) * 2;
try { bar.floating = false; } catch (e) {}

var menu = bar.addWidget("org.kde.plasma.kickoff");
menu.currentConfigGroup = ["General"];
menu.writeConfig("icon", "alize-start");

bar.addWidget("org.kde.plasma.appmenu");
bar.addWidget("org.kde.plasma.panelspacer");
bar.addWidget("org.kde.plasma.systemtray");
var clock = bar.addWidget("org.kde.plasma.digitalclock");
clock.currentConfigGroup = ["Appearance"];
clock.writeConfig("showDate", true);
clock.writeConfig("dateDisplayFormat", "BesideTime");
clock.writeConfig("dateFormat", "custom");
clock.writeConfig("customDateFormat", "ddd d MMM");

// --- Dock : lanceur plein écran, applications épinglées et ouvertes, corbeille ---
var dock = new Panel;
dock.location = "bottom";
dock.height = Math.round(gridUnit * 3.5 / 2) * 2;
try { dock.lengthMode = "fit"; } catch (e) {}
try { dock.alignment = "center"; } catch (e) {}
try { dock.floating = true; } catch (e) {}
try { dock.hiding = "dodgewindows"; } catch (e) {}

var grid = dock.addWidget("org.kde.plasma.kickerdash");
if (grid) {
    grid.currentConfigGroup = ["General"];
    grid.writeConfig("icon", "alize-apps");
    grid.writeConfig("useCustomButtonImage", true);
    grid.writeConfig("customButtonImage", "alize-apps");
}

var pinned = [
    "applications:org.kde.dolphin.desktop",
    "applications:firefox-esr.desktop",
    "applications:alize-exe.desktop",
    "applications:org.kde.discover.desktop",
    "applications:org.kde.konsole.desktop",
    "applications:systemsettings.desktop"
];
// En session live uniquement : l'installateur est épinglé en premier
if (applicationExists("alize-install.desktop") || applicationExists("alize-install")) {
    pinned.unshift("applications:alize-install.desktop");
}
var tasks = dock.addWidget("org.kde.plasma.icontasks");
tasks.currentConfigGroup = ["General"];
tasks.writeConfig("launchers", pinned);

try { dock.addWidget("org.kde.plasma.trash"); } catch (e) {}
