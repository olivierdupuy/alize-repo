#!/bin/bash
# Génère les jeux de couleurs KDE d'Alizé OS (clair + sombre) à partir de la palette.
# Usage : gen-colors.sh <répertoire de sortie>
set -euo pipefail
OUT="${1:?répertoire de sortie requis}"
mkdir -p "$OUT"

rgb() { local h="${1#\#}"; printf '%d,%d,%d' "0x${h:0:2}" "0x${h:2:2}" "0x${h:4:2}"; }

# colorset <nom> <fond> <fond alterné> <texte>
colorset() {
    cat <<EOF
[Colors:$1]
BackgroundAlternate=$(rgb "$3")
BackgroundNormal=$(rgb "$2")
DecorationFocus=$(rgb "$ACCENT")
DecorationHover=$(rgb "$ACCENT")
ForegroundActive=$(rgb "$LINK")
ForegroundInactive=$(rgb "$MUTED")
ForegroundLink=$(rgb "$LINK")
ForegroundNegative=$(rgb "$NEG")
ForegroundNeutral=$(rgb "$NEU")
ForegroundNormal=$(rgb "$4")
ForegroundPositive=$(rgb "$POS")
ForegroundVisited=$(rgb "$VISITED")

EOF
}

# scheme <identifiant> <nom affiché>
scheme() {
    {
        colorset View "$VIEW" "$ALT" "$FG"
        colorset Window "$WINDOW" "$ALT" "$FG"
        colorset Button "$BUTTON" "$ALT" "$FG"
        colorset Tooltip "$TOOLTIP" "$ALT" "$FG"
        colorset Header "$HEADER" "$WINDOW" "$FG"
        colorset "Header][Inactive" "$WINDOW" "$WINDOW" "$FG"
        # Texte blanc sur l'accent : contraste >= 4,5:1 dans les deux thèmes
        LINK="#ffffff" VISITED="#e3e9ff" MUTED="#dbe4ff" NEG="#ffd6dd" NEU="#ffe7b8" POS="#c9f7e1" \
            colorset Selection "$ACCENT" "$ACCENT_ALT" "#ffffff"
        # Surfaces toujours sombres (écran de déconnexion, superpositions)
        LINK="#8ab4ff" VISITED="#c4a7ff" MUTED="#9ea6b8" NEG="#f0506e" NEU="#f5a524" POS="#3ecf8e" \
            colorset Complementary "#15171d" "#1a1d25" "#e8eaf0"
        cat <<EOF
[ColorEffects:Disabled]
Color=56,56,56
ColorAmount=0
ColorEffect=0
ContrastAmount=0.65
ContrastEffect=1
IntensityAmount=0.1
IntensityEffect=2

[ColorEffects:Inactive]
ChangeSelectionColor=true
Color=112,111,110
ColorAmount=0.025
ColorEffect=2
ContrastAmount=0.1
ContrastEffect=2
Enable=false
IntensityAmount=0
IntensityEffect=0

[General]
ColorScheme=$1
Name=$2
shadeSortColumn=true

[KDE]
contrast=4

[WM]
activeBackground=$(rgb "$HEADER")
activeBlend=$(rgb "$FG")
activeForeground=$(rgb "$FG")
inactiveBackground=$(rgb "$WINDOW")
inactiveBlend=$(rgb "$MUTED")
inactiveForeground=$(rgb "$MUTED")
EOF
    } > "$OUT/$1.colors"
}

# --- Alizé Clair (défaut) ---
WINDOW="#f4f5f8" VIEW="#ffffff" ALT="#f0f2f7" BUTTON="#ffffff" TOOLTIP="#ffffff" HEADER="#e9ebf1"
FG="#1c1e26" MUTED="#5a6170" ACCENT="#2563eb" ACCENT_ALT="#1d4ed8"
LINK="#1d4ed8" VISITED="#6d28d9" NEG="#c8233f" NEU="#a35a00" POS="#12804f"
scheme AlizeLight "Alizé Clair"

# --- Alizé Sombre ---
WINDOW="#15171d" VIEW="#101217" ALT="#1a1d25" BUTTON="#242833" TOOLTIP="#1d2029" HEADER="#111318"
FG="#e8eaf0" MUTED="#9ea6b8" ACCENT="#2563eb" ACCENT_ALT="#1d4ed8"
LINK="#8ab4ff" VISITED="#c4a7ff" NEG="#f0506e" NEU="#f5a524" POS="#3ecf8e"
scheme AlizeDark "Alizé Sombre"
