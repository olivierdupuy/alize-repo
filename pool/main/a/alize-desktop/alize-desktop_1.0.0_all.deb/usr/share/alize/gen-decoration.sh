#!/bin/bash
# Génère les décorations de fenêtre d'Alizé OS (thèmes Aurorae clair + sombre) :
# barre de titre arrondie, ombre douce, boutons ronds colorés.
# Usage : gen-decoration.sh <répertoire des thèmes Aurorae>
set -euo pipefail
OUT="${1:?répertoire de sortie requis}"

# Géométrie (px) : P = marge d'ombre, T = hauteur de la barre de titre, R = rayon des coins
P=24; T=32; R=10; C=12; M=40
X1=$((P + C)); X2=$((X1 + M)); X3=$((X2 + C + P))
Y1=$((P + T)); Y2=$((Y1 + M)); Y3=$((Y2 + P))

# frame <préfixe> <couleur de barre> <opacité de l'ombre> <décalage vertical dans le SVG>
frame() {
    local p="$1" title="$2" a="$3" dy="$4" g="g$1"
    local am; am=$(awk "BEGIN{print $a*0.3}")
    local stops="<stop offset='0' stop-color='#000' stop-opacity='$a'/><stop offset='0.45' stop-color='#000' stop-opacity='$am'/><stop offset='1' stop-color='#000' stop-opacity='0'/>"
    local rs; rs=$(awk "BEGIN{print $R/($P+$R)}")
    local rstops="<stop offset='0' stop-color='#000' stop-opacity='$a'/><stop offset='$rs' stop-color='#000' stop-opacity='$a'/><stop offset='$(awk "BEGIN{print $rs+(1-$rs)*0.45}")' stop-color='#000' stop-opacity='$am'/><stop offset='1' stop-color='#000' stop-opacity='0'/>"
    local cx=$((P + R)) cy=$((P + R)) rx=$((X3 - P - R))
    cat <<EOF
<g transform="translate(0 $dy)">
<defs>
  <linearGradient id="${g}u" gradientUnits="userSpaceOnUse" x1="0" y1="$P" x2="0" y2="0">$stops</linearGradient>
  <linearGradient id="${g}d" gradientUnits="userSpaceOnUse" x1="0" y1="$Y2" x2="0" y2="$Y3">$stops</linearGradient>
  <linearGradient id="${g}l" gradientUnits="userSpaceOnUse" x1="$P" y1="0" x2="0" y2="0">$stops</linearGradient>
  <linearGradient id="${g}r" gradientUnits="userSpaceOnUse" x1="$((X3 - P))" y1="0" x2="$X3" y2="0">$stops</linearGradient>
  <radialGradient id="${g}tl" gradientUnits="userSpaceOnUse" cx="$cx" cy="$cy" r="$((P + R))">$rstops</radialGradient>
  <radialGradient id="${g}tr" gradientUnits="userSpaceOnUse" cx="$rx" cy="$cy" r="$((P + R))">$rstops</radialGradient>
  <radialGradient id="${g}bl" gradientUnits="userSpaceOnUse" cx="$P" cy="$Y2" r="$P">$stops</radialGradient>
  <radialGradient id="${g}br" gradientUnits="userSpaceOnUse" cx="$((X3 - P))" cy="$Y2" r="$P">$stops</radialGradient>
</defs>
<g id="$p-topleft">
  <rect x="0" y="0" width="$X1" height="$Y1" fill="#000" fill-opacity="0"/>
  <rect x="0" y="0" width="$cx" height="$cy" fill="url(#${g}tl)"/>
  <rect x="0" y="$cy" width="$P" height="$((Y1 - cy))" fill="url(#${g}l)"/>
  <rect x="$cx" y="0" width="$((X1 - cx))" height="$P" fill="url(#${g}u)"/>
  <path d="M$P $Y1 V$cy A$R $R 0 0 1 $cx $P H$X1 V$Y1 Z" fill="$title"/>
</g>
<g id="$p-top">
  <rect x="$X1" y="0" width="$M" height="$P" fill="url(#${g}u)"/>
  <rect x="$X1" y="$P" width="$M" height="$T" fill="$title"/>
</g>
<g id="$p-topright">
  <rect x="$X2" y="0" width="$((X3 - X2))" height="$Y1" fill="#000" fill-opacity="0"/>
  <rect x="$rx" y="0" width="$((X3 - rx))" height="$cy" fill="url(#${g}tr)"/>
  <rect x="$((X3 - P))" y="$cy" width="$P" height="$((Y1 - cy))" fill="url(#${g}r)"/>
  <rect x="$X2" y="0" width="$((rx - X2))" height="$P" fill="url(#${g}u)"/>
  <path d="M$((X3 - P)) $Y1 V$cy A$R $R 0 0 0 $rx $P H$X2 V$Y1 Z" fill="$title"/>
</g>
<g id="$p-left">
  <rect x="0" y="$Y1" width="$X1" height="$M" fill="#000" fill-opacity="0"/>
  <rect x="0" y="$Y1" width="$P" height="$M" fill="url(#${g}l)"/>
</g>
<g id="$p-right">
  <rect x="$X2" y="$Y1" width="$((X3 - X2))" height="$M" fill="#000" fill-opacity="0"/>
  <rect x="$((X3 - P))" y="$Y1" width="$P" height="$M" fill="url(#${g}r)"/>
</g>
<g id="$p-bottomleft">
  <rect x="0" y="$Y2" width="$X1" height="$P" fill="#000" fill-opacity="0"/>
  <rect x="0" y="$Y2" width="$P" height="$P" fill="url(#${g}bl)"/>
  <rect x="$P" y="$Y2" width="$C" height="$P" fill="url(#${g}d)"/>
</g>
<rect id="$p-bottom" x="$X1" y="$Y2" width="$M" height="$P" fill="url(#${g}d)"/>
<g id="$p-bottomright">
  <rect x="$X2" y="$Y2" width="$((X3 - X2))" height="$P" fill="#000" fill-opacity="0"/>
  <rect x="$((X3 - P))" y="$Y2" width="$P" height="$P" fill="url(#${g}br)"/>
  <rect x="$X2" y="$Y2" width="$C" height="$P" fill="url(#${g}d)"/>
</g>
<rect id="$p-center" x="$X1" y="$Y1" width="$M" height="$M" fill="$title"/>
</g>
EOF
}

# button <fichier> <couleur> <assombrissement enfoncé, en %> <gris fenêtre inactive> <tracé du symbole>
button() {
    local f="$1" col="$2" down="$3" gray="$4" glyph="$5" i=0 s
    {
        echo '<svg xmlns="http://www.w3.org/2000/svg" width="160" height="14" viewBox="0 0 160 14">'
        # état:couleur:options (g = symbole visible, p = assombri quand enfoncé)
        for s in active:"$col": inactive:"$gray": hover:"$col":g pressed:"$col":gp deactivated:"$gray": \
                 hover-inactive:"$col":g pressed-inactive:"$col":gp deactivated-inactive:"$gray":; do
            IFS=: read -r name fill opts <<<"$s"
            echo "<g id=\"$name-center\" transform=\"translate($((i * 20)) 0)\"><circle cx=\"7\" cy=\"7\" r=\"7\" fill=\"$fill\"/>"
            case "$opts" in *p*) echo "<circle cx=\"7\" cy=\"7\" r=\"7\" fill=\"#000\" fill-opacity=\"0.$down\"/>" ;; esac
            case "$opts" in g*) echo "<path d=\"$glyph\" fill=\"none\" stroke=\"#000\" stroke-opacity=\"0.6\" stroke-width=\"1.6\" stroke-linecap=\"round\"/>" ;; esac
            echo '</g>'
            i=$((i + 1))
        done
        echo '</svg>'
    } > "$f"
}

# theme <identifiant> <nom> <barre active> <barre inactive> <texte actif> <texte inactif> <gris des boutons> <rouge> <ambre> <vert>
theme() {
    local id="$1" name="$2" ta="$3" ti="$4" fa="$5" fi="$6" gray="$7" red="$8" amber="$9" green="${10}"
    local d="$OUT/$id"
    mkdir -p "$d"
    {
        echo "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"$X3\" height=\"$((Y3 * 2 + 10))\" viewBox=\"0 0 $X3 $((Y3 * 2 + 10))\">"
        frame decoration "$ta" 0.30 0
        frame decoration-inactive "$ti" 0.18 $((Y3 + 10))
        echo '</svg>'
    } > "$d/decoration.svg"
    button "$d/close.svg"    "$red"   18 "$gray" "M4.5 4.5 L9.5 9.5 M9.5 4.5 L4.5 9.5"
    button "$d/minimize.svg" "$amber" 18 "$gray" "M4 7 H10"
    button "$d/maximize.svg" "$green" 18 "$gray" "M7 4 V10 M4 7 H10"
    button "$d/restore.svg"  "$green" 18 "$gray" "M4.5 5.5 H9.5 M4.5 8.5 H9.5"
    cat > "$d/${id}rc" <<EOF
[General]
ActiveTextColor=$(rgb "$fa"),255
InactiveTextColor=$(rgb "$fi"),255
UseTextShadow=false
TitleAlignment=Center
TitleVerticalAlignment=Center
Animation=150
Shadow=true

[Layout]
BorderLeft=0
BorderRight=0
BorderBottom=0
TitleEdgeTop=9
TitleEdgeBottom=9
TitleEdgeLeft=12
TitleEdgeRight=12
TitleEdgeTopMaximized=9
TitleEdgeBottomMaximized=9
TitleEdgeLeftMaximized=12
TitleEdgeRightMaximized=12
TitleBorderLeft=8
TitleBorderRight=8
TitleHeight=14
ButtonWidth=14
ButtonHeight=14
ButtonSpacing=8
ButtonMarginTop=0
ExplicitButtonSpacer=10
PaddingTop=$P
PaddingBottom=$P
PaddingLeft=$P
PaddingRight=$P
EOF
    cat > "$d/metadata.desktop" <<EOF
[Desktop Entry]
Name=$name
Comment=Décoration de fenêtre d'Alizé OS
X-KDE-PluginInfo-Name=$id
X-KDE-PluginInfo-Version=1.0
X-KDE-PluginInfo-License=GPL-2.0-or-later
EOF
}

rgb() { local h="${1#\#}"; printf '%d,%d,%d' "0x${h:0:2}" "0x${h:2:2}" "0x${h:4:2}"; }

# Les boutons gardent un contraste d'au moins 3:1 avec la barre de titre dans chaque thème
theme Alize     "Alizé"        "#ececf1" "#f4f5f8" "#1c1e26" "#5a6170" "#aeb4c0" "#d63a55" "#c27803" "#12804f"
theme AlizeDark "Alizé Sombre" "#1a1d25" "#15171d" "#e8eaf0" "#9ea6b8" "#5b6170" "#f0506e" "#f5a524" "#3ecf8e"
